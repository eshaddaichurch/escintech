  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Elshaddai Church</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url('images/icon.png') ?>" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?php echo site_url('assets/bethany/') ?>assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo site_url('assets/bethany/') ?>assets/css/style.css" rel="stylesheet">

  <!-- datatables -->
  <link href="<?php echo (base_url("admin/assets/")) ?>datatables2/css/jquery.dataTables.min.css" rel="stylesheet">

  <!-- jquery-confirm -->
  <link rel="stylesheet" href="<?php echo (base_url("admin/assets/")) ?>jquery-confirm/css/jquery-confirm.min.css">

  <!-- jquery-ui -->
  <link rel="stylesheet" href="<?php echo (base_url("admin/assets/")) ?>jquery-ui/themes/base/jquery-ui.css">

  <!-- Font Awesome Icons 5.1 -->
  <link rel="stylesheet" href="<?php echo (base_url()) ?>admin/assets/adminlte/plugins/fontawesome-free/css/all.min.css">

  <!-- Google Font: Source Sans Pro -->
  <link href="<?php echo (base_url()) ?>admin/assets/googleapis/googleapis.css" rel="stylesheet">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!-- select2 -->
  <link href="<?php echo (base_url()) ?>admin/assets/select2/css/select2.min.css" rel="stylesheet" />

  <!-- custom -->
  <link href="<?php echo (base_url()) ?>admin/assets/custom/custom.css" rel="stylesheet" />
  <!-- =======================================================
  * Template Name: Bethany - v4.7.0
  * Template URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->